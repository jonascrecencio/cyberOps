-- Enable hyperscan for IPS, AppID and HTTP inspection
-- Enable hyperscan for pcre/regex matches
search_engine = { search_method = "" }
detection = { hyperscan_literals = false, pcre_to_regex = false }
